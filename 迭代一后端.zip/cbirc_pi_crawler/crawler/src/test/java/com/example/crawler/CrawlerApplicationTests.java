package com.example.crawler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrawlerApplicationTests {

    @Test
    void contextLoads() {
    }
    @Test
    void webservice(){

    }

}
