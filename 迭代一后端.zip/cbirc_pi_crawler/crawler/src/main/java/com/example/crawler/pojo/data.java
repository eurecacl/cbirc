package com.example.crawler.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class data {
    public String  content;
    public  int id;
}
