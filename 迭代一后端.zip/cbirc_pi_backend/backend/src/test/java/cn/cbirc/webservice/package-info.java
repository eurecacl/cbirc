@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.cbirc.cn")
package cn.cbirc.webservice;
