package cn.cbirc.model.vo;

import lombok.Data;

@Data
public class PolicyRetrievalVO {
    int piId;
    String text;
}
