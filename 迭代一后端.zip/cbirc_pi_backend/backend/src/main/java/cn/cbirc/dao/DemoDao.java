package cn.cbirc.dao;

import org.springframework.stereotype.Repository;


/**
 * TODO: delete this file
 * 关于文档解读的数据访问均通过webservice封装的服务进行调用
 * 步骤：
 * 1. 启动 webservice module 的服务
 * 2. 安装文档生成代理类 https://www.cnblogs.com/wlv1314/p/12157568.html
 * 3. 如下调用
 *
 * 关于用户信息的数据相关的，在backend直接调数据库
 */
@Repository
public class DemoDao {
}
